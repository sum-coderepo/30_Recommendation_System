import React from "react";
import "./search.css";
import { useNavigate } from 'react-router-dom';
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import Link from "@mui/material/Link";
import Autocomplete, { createFilterOptions } from "@mui/material/Autocomplete";

import Table from "./Table";

const BACKEND_URI = "http://localhost:3001/app/";
const filter = createFilterOptions();

function Search() {
  const [value, setValue] = React.useState(null);
  const [history, setHistory] = React.useState([]);
  const [searchResponse, setSearchResponse] = React.useState();
  const [submittedQuery, setSubmittedQuery] = React.useState();
  // const [searchapiresponse, setsearchapiresponse] = React.useState([]);
  const [age, setAge] =  React.useState("");
  const [APIData, setAPIData] =  React.useState([])
  const [filteredResults, setFilteredResults] =  React.useState([]);
  const [searchInput, setSearchInput] =  React.useState('');
  const [searchapiresponse, setsearchapiresponse] =  React.useState();

  const email = sessionStorage.getItem("curr_email");
      // const email = sessionStorage.getItem("curr_email");

  const searchItems = (searchValue) => {
      
      setSearchInput(searchValue)
  }
  const dummyData = [];
  const [options, setOptions] = React.useState(dummyData);

  const [researchArea, _setResearchArea] = React.useState(['Accelerator Physics', 'Adaptation and Self-Organizing Systems', 'Algebraic Geometry', 'Algebraic Topology', 'Analysis of PDEs', 'Applications', 'Applied Physics', 'Artificial Intelligence', 'Astrophysics', 'Astrophysics of Galaxies', 'Atmospheric and Oceanic Physics', 'Atomic Physics', 'Atomic and Molecular Clusters', 'Audio and Speech Processing', 'Biological Physics', 'Biomolecules', 'Category Theory', 'Cell Behavior', 'Cellular Automata and Lattice Gases', 'Chaotic Dynamics', 'Chemical Physics', 'Classical Analysis and ODEs', 'Classical Physics', 'Combinatorics', 'Commutative Algebra', 'Complex Variables', 'Computation', 'Computation and Language', 'Computational Complexity', 'Computational Engineering, Finance, and Science', 'Computational Finance', 'Computational Geometry', 'Computational Physics', 'Computer Science and Game Theory', 'Computer Vision and Pattern Recognition', 'Computers and Society', 'Cosmology and Nongalactic Astrophysics', 'Cryptography and Security', 'Data Analysis, Statistics and Probability', 'Data Structures and Algorithms', 'Databases', 'Differential Geometry', 'Digital Libraries', 'Discrete Mathematics', 'Disordered Systems and Neural Networks', 'Distributed, Parallel, and Cluster Computing', 'Dynamical Systems', 'Earth and Planetary Astrophysics', 'Econometrics', 'Economics', 'Emerging Technologies', 'Exactly Solvable and Integrable Systems', 'Fluid Dynamics', 'Formal Languages and Automata Theory', 'Functional Analysis', 'General Finance', 'General Literature', 'General Mathematics', 'General Physics', 'General Relativity and Quantum Cosmology', 'General Topology', 'Genomics', 'Geometric Topology', 'Geophysics', 'Graphics', 'Group Theory', 'Hardware Architecture', 'High Energy Astrophysical Phenomena', 'High Energy Physics - Experiment', 'High Energy Physics - Lattice', 'High Energy Physics - Phenomenology', 'High Energy Physics - Theory', 'History and Overview', 'History and Philosophy of Physics', 'Human-Computer Interaction', 'Image and Video Processing', 'Information Retrieval', 'Information Theory', 'Information Theory', 'Instrumentation and Detectors', 'Instrumentation and Methods for Astrophysics', 'K-Theory and Homology', 'Logic', 'Logic in Computer Science', 'Machine Learning', 'Machine Learning', 'Materials Science', 'Mathematical Finance', 'Mathematical Physics', 'Mathematical Physics', 'Mathematical Software', 'Medical Physics', 'Mesoscale and Nanoscale Physics', 'Methodology', 'Metric Geometry', 'Molecular Networks', 'Multiagent Systems', 'Multimedia', 'Networking and Internet Architecture', 'Neural and Evolutionary Computing', 'Neurons and Cognition', 'Nuclear Experiment', 'Nuclear Theory', 'Number Theory', 'Numerical Analysis', 'Numerical Analysis', 'Operating Systems', 'Operator Algebras', 'Optics', 'Optimization and Control', 'Other Computer Science', 'Other Condensed Matter', 'Other Quantitative Biology', 'Other Statistics', 'Pattern Formation and Solitons', 'Performance', 'Physics Education', 'Physics and Society', 'Plasma Physics', 'Popular Physics', 'Populations and Evolution', 'Portfolio Management', 'Pricing of Securities', 'Probability', 'Programming Languages', 'Quantitative Methods', 'Quantum Algebra', 'Quantum Gases', 'Quantum Physics', 'Representation Theory', 'Rings and Algebras', 'Risk Management', 'Robotics', 'Signal Processing', 'Social and Information Networks', 'Soft Condensed Matter', 'Software Engineering', 'Solar and Stellar Astrophysics', 'Sound', 'Space Physics', 'Spectral Theory', 'Statistical Finance', 'Statistical Mechanics', 'Statistics Theory', 'Statistics Theory', 'Strongly Correlated Electrons', 'Subcellular Processes', 'Superconductivity', 'Symbolic Computation', 'Symplectic Geometry', 'Systems and Control', 'Tissues and Organs', 'Trading and Market Microstructure'])
  const [researchAreaSelection, setResearchAreaSelection] = React.useState("");

  const handleChange = (event) => {
    setResearchAreaSelection(event.target.value);
  };
  const navigate = useNavigate();

      const navigateToProfile = () => {
          navigate('/profile');
      }
  const preventDefault = (event) => event.preventDefault();

  const fetchData = () => {
    const query1 = {
      query1: value.label,
      link: researchAreaSelection,
    };

    setHistory((prevHistory) => [
      {
        query: `${value.label} ${researchAreaSelection}`,
        link: "http://googl.com",
      },
      ...prevHistory,
    ]);

let response = fetch("http://localhost:8004/predict",
         {
             method: "POST",
             //body: query,
             headers: {
                 'Accept': 'application/json',
                 'Content-Type': 'application/json'
             },
             body: JSON.stringify(value.label + "||" + researchAreaSelection),

         })
          .then(function(res){
              return res.json();
          })
    .then(function(data){
        // console.log("data", data.hits.hits);
        setsearchapiresponse(data.hits?.hits?.map(item => item._source))
    })
    .catch(function(res){ console.log(res) })
  };

  return (
    <div id='main'>
      <br></br>
      <br></br>
      <br></br>
      <div id="ac"><Autocomplete
        value={value}
        onChange={(event, newValue) => {
          if (typeof newValue === "string") {
            setValue({
              label: newValue,
            });
          } else if (newValue && newValue.inputValue) {
            // Create a new value from the user input
            setValue({
              label: newValue.inputValue,
            });
            // setOptions(prevValue => ([
            //   ...prevValue,
            //   {
            //     label: newValue.inputValue,
            //     year: 2000,
            //   }
            // ]));
          } else {
            setValue(newValue);
          }
        }}
        filterOptions={(options, params) => {
          const filtered = filter(options, params);

          const { inputValue } = params;
          // Suggest the creation of a new value
          const isExisting = options.some(
            (option) => inputValue === option.label
          );
          if (inputValue !== "" && !isExisting) {
            filtered.push({
              inputValue,
              label: `Add "${inputValue}"`,
            });
          }

          return filtered;
        }}
        selectOnFocus
        clearOnBlur
        handleHomeEndKeys
        id="free-solo-with-text-demo"
        options={options}
        getOptionLabel={(option) => {
          // Value selected with enter, right from the input
          if (typeof option === "string") {
            return option;
          }
          // Add "xxx" option created dynamically
          if (option.inputValue) {
            return option.inputValue;
          }
          // Regular option
          return option.label;
        }}
        renderOption={(props, option) => <li {...props}>{option.label}</li>}
        sx={{ width: 300 }}
        freeSolo
        renderInput={(params) => (
          <TextField {...params} label="Research paper" />
        )}
      />
      <br></br>
      <br></br>
      <br></br>
      <Box sx={{ minWidth: 120 }}>
        <FormControl id="form">
          <InputLabel id="demo-simple-select-label">RESEARCH AREA</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={researchAreaSelection}
            label="RESEARH AREA"
            onChange={handleChange}
          >
            {researchArea.map(item => (
              <MenuItem value={item}>{item}</MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
      <br></br>
      <button type="button" className="btn btn-outline-primary" onClick={async (e) => {
                        fetchData();
                        // send fetch (POST) request to server
                        const requestOptions = {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ email: email, searchInput: value.label, age: researchAreaSelection })
                        };

                        var res = await fetch(BACKEND_URI + "search", requestOptions);
                        // alert((await res.json())["msg"]);
                        setSearchInput("");
                        setAge("");
                    }}>
                            Search
                    </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <button id = "profile" type="button" className="btn btn-outline-primary" onClick={async (e) => {
                        navigateToProfile();
                        // send fetch (POST) request to server
                        }}>
                          Profile
                    </button>
      <br></br>
      </div>
      <br></br>
      <br></br>
      <p>
        
        
      </p>
      <br></br>
      {/* *
      * displaying search result
       */}
      {/* {searchResponse?.length ? (<>
        <div style={{fontSize: 23, fontWeight: "bold"}}>Search Result Response for query <i>{submittedQuery.query}</i> in <i>{submittedQuery.researchAreaSelection}</i> is </div>
        <ul>
        {/* {searchResponse?.map(item => (
                // <li>
                //     <Link href={item.link}>{item.documentTitle}</Link>
                // </li>
            ))} */}
        {/* </ul> */}
        {/* </>) : null} */}
      <br></br>
      <br></br>
      <br></br>
      <Box
        sx={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          typography: "body1",
          "& > :not(style) + :not(style)": {
            ml: 2,
          },
        }}
        onClick={preventDefault}
      >
        
            </Box>
            {/* displaying previous searches */}
        {/* <ul>
            {history?.slice(0, 5)?.map(item => (
                // <li>
                //     <Link href={item.link}>{item.query}</Link>
                // </li>
            ))}
        </ul> */}
        {/* <Link href="#" underline="hover">
          {'underline="hover"'}
        </Link>
        <Link href="#" underline="always">
          {'underline="always"'}
        </Link> */}

        {searchapiresponse?.length && <Table data={searchapiresponse} />}
    </div>
  );
}

export default Search;
