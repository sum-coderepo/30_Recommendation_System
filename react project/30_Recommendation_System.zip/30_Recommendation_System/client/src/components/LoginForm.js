import React from "react";
import "../common_login.css";
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
const BACKEND_URI = "http://localhost:3001/app/";

// functional component
function LoginForm(props) {
    
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const navigateToProfile = () => {
        navigate('/search');
    }

    

    return (
        <div class="login-box">
  <h2>Login</h2>
  <form>
    <div class="user-box">
      <input type="text" name="email" required="true" value={email} onChange={(e) => setEmail(e.target.value)}/>
      <label>Email Id</label>
    </div>
    <div class="user-box">
      <input type="password" name="password" required="true" value={password} onChange={(e) => setPassword(e.target.value)}/>
      <label>Password</label>
    </div>
    <a onClick={async (e) =>  {
                // send fetch (POST) request to server
                const requestOptions = {
                    credentials : 'include',
                    method : 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body : JSON.stringify({ email : email, password : password })
                };

                const emailvalidator=()=>{
                  const regex=/[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,8}(.[a-z{2,8}])?/g
                  if(!regex.test(email) && email != ""){
                    alert("Email is not valid !! ")
                  }
                }

                var res = await fetch(BACKEND_URI + "login", requestOptions);
                // alert((await res.json())["msg"]);
                setEmail("");
                setPassword("");
                if(res.status == 200) {
                  // fetchData();
                    sessionStorage.setItem("curr_email", email);
                    navigateToProfile();

                }
                
                
                }}>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>Login</a>

            <br/>
            <p className='m-4' id='noacc'>Do not have an account ? <Link to='/signup'> Sign Up Here</Link> </p>
  </form>
</div>);
    
}

export default LoginForm;