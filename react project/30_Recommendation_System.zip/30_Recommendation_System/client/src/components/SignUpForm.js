import { useState } from 'react';
import { Link } from 'react-router-dom';
import "../common_signup.css"

const BACKEND_URI = "http://localhost:3001/app/";

// functional component
function SignUpForm(props) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");   
    const [name, setName] = useState("");
    const [age, setAge] = useState("");


    return (
        <div class="login-box">
            <h2>SignUp</h2>
            <form>
                <div class="user-box">
                    <input type="text" name="name" required="true" value={name} onChange={(e) => setName(e.target.value)} />
                    <label>Name</label>
                </div>
                <div class="user-box">
                    <input type="text" name="age" required="true" value={age} onChange={(e) => setAge(e.target.value)} />
                    <label>Age</label>
                </div>
                <div class="user-box">
                    <input type="text" name="email" required="true" value={email} onChange={(e) => setEmail(e.target.value)} />
                    <label>Email Id</label>
                </div>
                <div class="user-box">
                    <input type="password" name="password" required="true" value={password} onChange={(e) => setPassword(e.target.value)} />
                    <label>Password</label>
                </div>
                <a onClick={async (e) => {
                    // send fetch (POST) request to server
                    const requestOptions = {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email: email, password: password, age: age, name: name })
                    };

                    var res = await fetch(BACKEND_URI + "signup", requestOptions);
                    alert((await res.json())["msg"]);
                    setEmail("");
                    setPassword("");
                    setAge("");
                    setName("");
                }}>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>SignUp</a>
                <br />
                <p className='m-4' id='log'>Already Registered ?<Link to='/login'> Login Here</Link> </p>
            </form>
        </div>);

}

export default SignUpForm;