import * as React from 'react';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';

function Row(props) {
  const { row } = props;
  const [open, setOpen] = React.useState(false);

  return (
    <React.Fragment>
      <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            style={{outline: 'none', border: 'none', height: 50, width: 50,}}
            onClick={() => setOpen(!open)}
          >
            {open ? '-': '+' }
          </IconButton>
        </TableCell>
        <TableCell align="left">
          {row.id}
        </TableCell>
        <TableCell align="left">{row.author}</TableCell>
        <TableCell align="left">{row.title}</TableCell>
        <TableCell align="left"><a href={row.link} target="_blank" rel="noreferrer">{row.link}</a></TableCell>
        <TableCell align="left">{row.updateDate}</TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              <Typography gutterBottom component="div">
                {row.abstract}
              </Typography>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

export default function CollapsibleTable({data}) {

  const rows = data.map((item) => {
    return ({
      id: item.id,
      author: JSON.parse(item.Authors?.replaceAll("'",'"')).map(item => item.slice(0, 2)?.reverse()?.join(' '))?.join(', '),
      title: item.title,
      updateDate: item.update_date,
      abstract: item.abstract,
      link: "https://arxiv.org/pdf/" + (("0000"+item.paper_id.toString().split(".")?.[0]).slice(-4)) +"." + item.paper_id.toString().split(".")?.[1]+".pdf",  //"https://arxiv.org/pdf/" + {condition} + paper_id+".pdf"
      //https://arxiv.org/pdf/0912.0717.pdf
    })
  })
  return (
    <TableContainer component={Paper}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow>
            <TableCell align="center"/>
            <TableCell align="left">Id</TableCell>
            <TableCell align="left">Authors</TableCell>
            <TableCell align="left">Title</TableCell>
            <TableCell align="left">Link</TableCell>
            <TableCell align="left">Update date</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <Row key={row.name} row={row} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}