const mongoose = require("mongoose");

const SearchSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
    },
    search: {
        type: String,
        required: true,
    },
    category: {
        type: String,
        required: true,
    },
}, { timestamps: true });

const Searchmodel = mongoose.model("search", SearchSchema);
module.exports = Searchmodel