const express = require('express')
const { json } = require('express')
const router = express.Router()
const UserSchema = require('../models/users')
const bcrypt = require('bcrypt')
const jwt = require("jsonwebtoken");

const JWT_SECRET = 'verySecretValuehcvdksheljlvkkl'

router.post('/signup', async (request, response) => {
    const saltpwd = await bcrypt.genSalt(10)
    const securepwd = await bcrypt.hash(request.body.password, saltpwd)
    
    
    const signedUpUser = new UserSchema({
        name: request.body.name,
        age: request.body.age,
        email: request.body.email,
        password: securepwd
    })
    signedUpUser.save()
    .then(data =>{
        response.json({res:"User added"})
    })
    .catch(error => {
        response.json(error)
    })
})

router.post('/login', async (req, res) => {

    const email = req.body.email
    const password = req.body.password
    const user = await UserSchema.findOne({ email })

    if (!user) {
        return res.json({ status: 'error', error: 'Invalid email'})
    }
    if (await bcrypt.compare(password, user.password)) {

        const token = jwt.sign({ 
            email: user.email,
            password: user.password
        }, JWT_SECRET, {expiresIn: '5h'})
        return res.json({status: 200, data: token})
    }

    res.json({status: 'error', error: 'Invalid password'})
})

module.exports = router