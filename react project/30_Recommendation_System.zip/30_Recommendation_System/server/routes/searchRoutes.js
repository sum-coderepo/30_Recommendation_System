const express = require('express')
const { json } = require('express')
const router = express.Router()
const SearchSchema = require('../models/Search')

router.post('/search', async (request, response) => {
    // const saltpwd = await bcrypt.genSalt(10)
    // const securepwd = await bcrypt.hash(request.body.password, saltpwd)
    // console.log(request.body)
    const searches = new SearchSchema({
        email: request.body.email,
        search: request.body.searchInput,
        category: request.body.age
    })
    searches.save()
        .then(data => {
            response.json({ res: "Search history added" })
        })
        .catch(error => {
            response.json(error)
        })
})


module.exports = router